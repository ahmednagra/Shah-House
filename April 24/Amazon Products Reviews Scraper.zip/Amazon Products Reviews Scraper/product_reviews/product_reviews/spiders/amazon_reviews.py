from datetime import datetime
from urllib.parse import quote
from collections import OrderedDict


import requests
from scrapy import Request, Spider, Selector


class AmazonReviewsSpider(Spider):
    name = "amazon_reviews"
    base_url = 'https://www.amazon.com'
    start_urls = ["https://www.amazon.com"]

    custom_settings = {
        'CONCURRENT_REQUESTS': 2,
        'RETRY_TIMES': 5,
        'RETRY_HTTP_CODES': [500, 502, 503, 504, 400, 403, 404, 408],

        'FEEDS': {
            f'output/Amazon Products Reviews {datetime.now().strftime("%d%m%Y%H%M")}.csv': {
                'format': 'csv',
                'fields': ['Part No', 'Question', 'Answer', 'Url']
            }
        }
    }

    def __init__(self):
        super().__init__()
        self.part_numbers = self.read_input_from_file('input/part_numbers.txt')
        self.proxy_token = self.read_input_from_file('input/proxy_key.txt')
        self.cookies = quote('i18n-prefs=AUD; lc-main=en_US')
        self.proxy = f"http://{self.proxy_token[0]}:setCookies={self.cookies}&geoCode=us@proxy.scrape.do:8080" if self.proxy_token else ''

    def start_requests(self):
        for part_number in self.part_numbers:
            url = f'https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords={part_number}'
            yield Request(url=url, callback=self.parse_part_number, meta={'proxy': self.proxy, 'part_number': part_number})

    def parse_part_number(self, response):
        # Extracting product information
        part_number = response.meta.get('part_number', '')

        for product in response.css('[data-component-type="s-search-result"]'):
            title = product.css('h2 a span::text').get('')
            asin = product.css('div::attr(data-asin)').get('')
            reviews_count = product.css('.alf-search-csa-instrumentation-wrapper span::attr(aria-label)').get('')

            if part_number in title and reviews_count:
                # use Requests Library for response using product Asin No
                req = self.get_product_reviews(asin)

                html_selector = Selector(text=req.text)
                raw_strings = html_selector.css('.a-section.a-spacing-base:contains("Q:")') or []

                for string in raw_strings:
                    try:
                        item = OrderedDict()
                        item['Part No'] = part_number
                        item['Question'] = ''.join(string.css('.a-text-bold:contains("Q:") + span::text').getall())

                        answer = string.css('.noScriptDisplayLongText ::text').getall() or string.css('div.a-section.a-spacing-none > span:not(.a-text-bold):not(#askAuthorDetails)::text').getall() or []

                        # Split the answer into words to limit the answer first 20 words
                        words = [word.strip() for text in answer for word in text.split() if word.strip()]
                        item['Answer'] = ' '.join(words[:20])
                        item['Url'] = f'https://www.amazon.com/dp/{asin}/'

                        yield item

                    except Exception as e:
                        self.logger.error(f"Error occurred while parsing product information: {e}")
                        # You can choose to handle the error in different ways, such as skipping the item or logging the error for debugging purposes
                        continue

    def get_product_reviews(self, asin):
        asin_url = f'https://www.amazon.com/ask/livesearch/detailPageSearch/search?query=%22work%22+%2C+%22%09%22+or+%22compatible%22&asin={asin}&liveSearchSessionId=&liveSearchPageLoadId='
        token = self.proxy_token[0]
        targetUrl = quote(asin_url)
        geoCode = "us"
        url = "http://api.scrape.do?token={}&url={}&setCookies={}&geoCode={}".format(token, targetUrl, self.cookies, geoCode)

        try:
            req = requests.get(url)
            req.raise_for_status()
            return req

        except requests.exceptions.RequestException as e:
            self.logger.error(f'Request to scrape.do API failed: {e}')
            return ''

    def read_input_from_file(self, file_path):
        try:
            with open(file_path, mode='r') as txt_file:
                return [line.strip() for line in txt_file.readlines() if line.strip()]

        except FileNotFoundError:
            print(f"File not found: {file_path}")
            return []
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return []
