import csv
from datetime import datetime
from urllib.parse import urlencode, urljoin, unquote
from collections import OrderedDict
from scrapy import Spider, Request


class UrlsSpider(Spider):
    name = "fbref"
    base_url = "https://fbref.com"

    custom_settings = {
        'CONCURRENT_REQUESTS': 3,

        'FEEDS': {
            f'output/Fbref scraper{datetime.now().strftime("%d%m%Y%H%M%S")}.csv': {
                'format': 'csv',
                'fields': ["Country", "Comp", "Season", "Round", "Wk", "Day", "Date", "Time", "Home", "xG_h", "Score",
                           "xG_a", "Away", "Attendance", "Venue", "Referee", "href", "CoachH", "CoachA", "CaptainH",
                           "CaptainA", "url_CaptainH", "url_CaptainA", "goal1", "goal2", "goal3", "goal4", "goal5",
                           "goal6", "goal7", "goal8", "goal9", "goal10", "goal11", "goal12", "goal13", "goal14",
                           "goal15", "goal16", "goal17", "goal18", "goal19", "goal20", "goal21", "goal22", "goal23",
                           "goal24", "goal25"],
            }
        }
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        filename = 'input/2_all_seasons_urls.csv'
        self.input_file = self.read_input_file(filename)
        self.current_items_scraped = 0
        self.key = self.get_proxy_key('input/proxy_key.txt').get('scrapeops_proxy_key', '')

    def start_requests(self):
        for item in self.input_file:
            url = item.get('Season URL', '')
            yield Request(url=self.get_scrapeops_url(url), callback=self.parse)

    def parse(self, response, **kwargs):
        try:
            # Extract competition name and season from the page
            comp = response.css('#sched_all_sh h2 span::text, #all_sched h2 span::text').re_first(r'\d.*?(\D+)$')
            comp = comp.strip() if comp else ''
            season = response.css('#meta h1::text').re_first(r'(\d+)')
            season = season.strip() if season else ''

            # Extract flags from the page
            # flags_values = response.css('table span.f-i::attr(style)').getall()
            # flags = [re.search(r"url\('([^']+)'\)", style).group(1) for style in flags_values]

            country = ''
            # Get modified headers
            headers = self.get_modify_headers(response)

            # Find index of 'Score' header
            score_index = headers.index('score')
            if not score_index:
                self.logger.error(f'No Headers found in the Url :{unquote(response.url).split('url=')[1]}')
                return

            # Iterate over table rows, skip first row for Headers
            for index, row in enumerate(response.css('table tr')[1:], start=1):
                cells = row.css('th, td')
                row_data = self.get_row_data(row)

                if len(cells) > score_index:  # Check if the cell exists
                    url = urljoin(self.base_url, row.css('[data-stat="match_report"] a::attr(href)').get(''))
                    print('Match Report Url :', url)
                    item = {
                        'comp': comp,
                        # 'flags': flags,
                        'season': season,
                        'country': country,
                        'match_report_url': url,
                        **dict(zip(headers, row_data))
                    }
                    yield Request(url=self.get_scrapeops_url(url), callback=self.parse_match, meta=item)
        except Exception as e:
            self.logger.error(f'Error Parse Function Error :{e} URL: {unquote(response.url).split('url=')[1]}')

    def parse_match(self, response):
        try:
            item = OrderedDict()

            # Extracting home team information
            teamH = response.css('.scorebox > div')
            coach_h = teamH.css('.datapoint:contains("Manager")::text').get('').replace(':', '').strip()
            captain_h = teamH.css('.datapoint:contains("Captain") a::text').get('')
            url_h = teamH.css('.datapoint:contains("Captain") a::attr(href)').get('')
            url_captain_h = urljoin(self.base_url, url_h) if url_h else ''
            team_h_goals = self.get_team_goals(key='H', selector=response.css('.scorebox #a >div'))

            # Extracting away team information
            team_a = response.css('.scorebox > div:nth-child(2), div#b')
            coach_a = team_a.css('.datapoint:contains("Manager")::text').get('').replace(':', '').strip()
            captain_a = team_a.css('.datapoint:contains("Captain") a::text').get('')
            url_a = team_a.css('.datapoint:contains("Captain") a::attr(href)').get('')
            url_captain_a = urljoin(self.base_url, url_a) if url_a else ''
            team_a_goals = self.get_team_goals(key='A', selector=response.css('.scorebox #b >div'))

            # Combine home and away team goals into a single list
            all_goals = team_h_goals + team_a_goals

            info = response.meta
            item['Country'] = info.get('country', '')
            item['Comp'] = info.get('comp', '')
            item['Season'] = info.get('season', '')
            item['Round'] = info.get('round', '')
            item['Wk'] = info.get('wk', '')
            item['Day'] = info.get('day', '')
            item['Date'] = info.get('date', '')
            item['Time'] = info.get('time', '')
            item['Home'] = info.get('home', '')
            item['xG_h'] = info.get('xg_h', '')
            item['Score'] = info.get('score', '')
            item['xG_a'] = info.get('xg_a', '')
            item['Away'] = info.get('away', '')
            item['Attendance'] = info.get('attendance', '')
            item['Venue'] = info.get('venue', '')
            item['Referee'] = info.get('referee', '')
            item['href'] = info.get('match_report_url', '')
            item['CoachH'] = coach_h
            item['CoachA'] = coach_a
            item['CaptainH'] = captain_h
            item['CaptainA'] = captain_a
            item['url_CaptainH'] = url_captain_h
            item['url_CaptainA'] = url_captain_a

            for i, goal in enumerate(all_goals):
                item[f"goal{i + 1}"] = goal if i < len(all_goals) else ""

            self.current_items_scraped += 1
            print('Current Scrapped Items :', self.current_items_scraped)

            yield item

        except Exception as e:
            self.logger.error(f'Error parse Match Detail Error :{e} URL:{unquote(response.url).split('url=')[1]}')

    def read_input_file(self, filename):
        """
        Read input data from a CSV file and return it as a list of dictionaries.

        Args:
            filename (str): The path to the CSV file.

        Returns:
            list: A list of dictionaries containing the data read from the CSV file.
                  Each dictionary represents a row, where the keys are the column headers
                  and the values are the corresponding row values.
                  Returns an empty list if the file is empty or cannot be read.
        """
        data = []
        try:
            with open(filename, mode='r', encoding='utf-8') as csvfile:
                csv_reader = csv.DictReader(csvfile)
                if csv_reader.fieldnames:
                    for row in csv_reader:
                        data.append(dict(row))
                else:
                    error = f"CSV file '{filename}' has no header or is empty."
                    print(error)
                    self.logger.error(error)
        except FileNotFoundError:
            error = f"File '{filename}' not found."
            print(error)
            self.logger.error(error)
        except Exception as e:
            error = f"An error occurred while reading the file '{filename}': {e}"
            print(error)
            self.logger.error(error)

        return data

    def get_scrapeops_url(self, url):
        payload = {'api_key': self.key, 'url': url}
        proxy_url = 'https://proxy.scrapeops.io/v1/?' + urlencode(payload)
        return proxy_url

    def get_row_data(self, row):
        try:
            data = []
            th = row.css('th a::text').get('')
            data.append(th)
            td_tags = row.css('td')
            for td in td_tags:
                if 'f-i' in td.get():
                    data.append(td.css('a ::text').get(''))
                    continue
                data.append(td.css('::text').get(''))
            return data
        except Exception as e:
            self.logger.error(f'Error parse Row data function')

    def get_modify_headers(self, response):
        headers = [header.strip().lower() for header in response.css('#sched_all thead tr th::text, #all_sched thead tr th::text').getall()]

        # Modify headers to handle multiple 'xG' columns
        xg_count = 0
        for i, header in enumerate(headers):
            if header == 'xg':
                xg_count += 1
                if xg_count == 1:
                    headers[i] = 'xg_h'
                elif xg_count == 2:
                    headers[i] = 'xg_a'

        return headers

    def get_team_goals(self, key, selector):
        goals = []
        try:
            for goal in selector:
                if goal.css('.yellow_red_card').get(''):
                    continue
                # Extract player name
                player_name = goal.css('a::text').get('').strip()

                # Extract player link
                player_link = goal.css('a::attr(href)').get('')
                playerH_link = urljoin(self.base_url, player_link) if player_link else ''

                # Extract goal time using regular expression
                time = goal.css('div::text').re_first(r'\b(\d+)\b')

                # Append goal details to the goals list
                goals.append(f"{key}_{time}_{player_name}_{playerH_link}")
        except Exception as e:
            # Handle any errors that may occur during goal extraction
            self.logger.error(f"Error extracting {key} team goals: {e}")

        return goals

    def get_proxy_key(self, filename):
        """
        Read a text file containing lines in the format "key==value" and return a dictionary.

        Args:
            filename (str): The path to the text file.

        Returns:
            dict: A dictionary containing key-value pairs from the text file.
        """
        result_dict = {}
        try:
            with open(filename, 'r') as file:
                for line in file:
                    parts = [part.strip() for part in line.split('==')]
                    if len(parts) == 2:
                        result_dict[parts[0]] = parts[1]
                    else:
                        print(f"Invalid line format: {line.strip()}. Skipping.")
        except FileNotFoundError:
            print(f"Error: File '{filename}' not found.")
            self.logger.error(f"Error: File '{filename}' not found.")
        except Exception as e:
            print(f"An error occurred while reading the file '{filename}': {e}")
            self.logger.error(f"An error occurred while reading the file '{filename}': {e}")
        return result_dict
