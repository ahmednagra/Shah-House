import csv
from collections import OrderedDict
from datetime import datetime
from math import ceil
from urllib.parse import urljoin

from scrapy import Request, Spider, Selector


class AdforumSpider(Spider):
    name = "adforum"
    base_url = 'https://www.adforum.com/'
    start_urls = ["https://www.adforum.com/talent/search"]

    custom_settings = {
        'RETRY_TIMES': 5,
        'RETRY_HTTP_CODES': [500, 502, 503, 504, 400, 403, 404, 408, 429, 10051],

        'FEEDS': {
            f'output/Ahs Company Products {datetime.now().strftime("%d%m%Y%H%M%S")}.csv': {
                'format': 'csv',
                'fields': ['Name', 'Title', 'Company', 'Location', 'Url'],
            }
        }
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        filename = 'input/search_parameters.csv'
        self.keyword = self.read_input_file(filename).get('Keyword', '')
        self.country = self.read_input_file(filename).get('Country', '')
        self.city = self.read_input_file(filename).get('City', '')
        self.current_items_scraped = 0

    def start_requests(self):
        """
        Start the spider by sending a request to the search page with the provided keyword and country.
        """
        if not self.city:
            url = f'{self.start_urls[0]}?worktitle={self.keyword}&location=country:{self.country}'
        else:
            url = f'{self.start_urls[0]}?worktitle={self.keyword}&location=city:{self.city},country:{self.country}'
            print('Full Url City and country', url)

        yield Request(url, callback=self.pagination)

    def pagination(self, response):
        """
        Handle pagination to extract talent information from multiple pages.
        """
        products = response.css('.b-search_result__title ::text').re_first(r'\b(\d+)\b') or 0
        self.logger.error(f'Total Products {len(products)} against Keyword: {self.keyword} and Country :{self.country}')

        if products and int(products) >= 25:
            total_pages = ceil(int(products) / 100)
            url_part = response.url.split('?')[1]

            for page_no in range(1, total_pages + 1):
                url = f'{self.base_url}find/loadmore?idx=people&l=100&p={page_no}&{url_part}&o=_score|desc&rtpl=people.list.search'
                yield Request(url, callback=self.parse, meta={'page_no': page_no})
        else:
            yield from self.parse(response)

    def parse(self, response, **kwargs):
        """
        Parse the search results page to extract talent information.
        """
        talents = []

        if 'page_no' in response.meta:
            try:
                data = response.json()
                records_html = data.get('html')
                html = Selector(text=records_html)
                talents = html.css('.personResult')
            except Exception as e:
                self.logger.error(f'Error parsing parse method for page {response.meta["page_no"]}: URL: {e}')
        else:
            talents = response.css('.appendable .personResult')

        for talent in talents:
            try:
                item = OrderedDict()

                # Extract talent information
                item['Name'] = talent.css('.talent-grid-name ::text').get('').strip()
                item['Title'] = talent.css('.talent-grid-position::text').get('').strip()
                item['Company'] = talent.css('.talent-grid-company ::text').get('').strip()
                item['Location'] = talent.css('.talent-grid-country ::text').get('').strip()

                # Extract talent profile URL
                url = talent.css('.talent-grid-company ::attr(href), .media-body a::attr(href)').get('')
                item['Url'] = urljoin(self.base_url, url) if url else ''
                self.current_items_scraped += 1
                print('Items are Scrapped = ', self.current_items_scraped)

                yield item
            except Exception as e:
                self.logger.error(f'Error Parsing item: {e}')

    def read_input_file(self, filename):
        """
        Read input data from a CSV file and return it as a dictionary.

        Args:
            filename (str): The path to the CSV file.

        Returns:
            dict: A dictionary containing the data read from the CSV file.
                  The keys are the column headers and the values are the corresponding row values.
                  Returns an empty dictionary if the file is empty or cannot be read.
        """
        data = {}
        try:
            with open(filename, mode='r', encoding='utf-8') as csvfile:
                csv_reader = csv.DictReader(csvfile)
                if csv_reader.fieldnames:
                    for row in csv_reader:
                        # Add each row to the data dictionary
                        data.update(dict(row))
                else:
                    error = f"CSV file '{filename}' has no header or is empty."
                    print(error)
                    self.logger.error(error)
        except FileNotFoundError:
            error = f"File '{filename}' not found."
            print(error)
            self.logger.error(error)
        except Exception as e:
            error = f"An error occurred while reading the file '{filename}': {e}"
            print(error)
            self.logger.error(error)

        return data


