import json
import re
from datetime import datetime
from math import ceil
from collections import OrderedDict
from scrapy import Spider, Request


class ChemistScraperSpider(Spider):
    name = 'chemist'
    start_urls = ['https://www.chemistwarehouse.com.au/']

    custom_settings = {
        'CONCURRENT_REQUESTS': 4,
        'FEEDS': {
            f'output/Chemist Warehouse Products {datetime.now().strftime("%d%m%Y%H%M")}.csv': {
                'format': 'csv',
                'fields': ['Product URL', 'Item ID', 'Product ID', 'Brand Name', 'Product Name', 'Regular Price',
                                          'Special Price', 'Short Description', 'Long Description', 'Product Information',
                                          'Directions', 'Ingredients', 'SKU', 'Image URLs'],
            }
        }
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def parse(self, response):
        categories = response.css('.category-tiles li:not(.mob-only) a::attr(href)').getall() or []
        for category in categories:
            category_id = category.split('/')[-2]
            category_format = 'chemau{category_id}'.format(category_id=category_id)
            urlp = '{catalog01_chemau}'
            url = f'https://pds.chemistwarehouse.com.au/search?identifier=AU&fh_start_index=0&fh_view_size=500&fh_location=//catalog01/en_AU/categories%3C{urlp}/categories%3C{category_format}'

            yield Request(url=url, callback=self.parse_pagination)

    def parse_pagination(self, response):
        data = self.get_json_data(response)
        total_products = data.get('universes', {}).get('universe', [{}])[0].get('items-section', {}).get('results', {}).get('total-items', '')

        if not total_products:
            return

        total_products = int(total_products)
        items_per_page = 500
        total_pages = ceil(total_products / items_per_page)

        if not total_pages:
            return

        for page_number in range(1, total_pages + 1):
            start_index = (page_number - 1) * items_per_page
            url = re.sub(r'fh_start_index=\d+', f'fh_start_index={start_index}', response.url)

            print('Next Page url is:', url)
            yield Request(url=url, callback=self.parse_products, dont_filter=True)

    def parse_products(self, response):
        data = self.get_json_data(response)
        products = data.get('universes', {}).get('universe', [])[0].get('items-section', {}).get('items', {}).get('item', [])

        for product in products:
            attributes = product.get('attribute', [])
            url = self.get_attribute(attributes, 'producturl')
            brand_name = self.get_attribute(attributes, 'brand')
            yield Request(url=url, callback=self.parse_product_detail, meta={'brand_name': brand_name})

    def parse_product_detail(self, response):
        item = OrderedDict()

        try:
            data = json.loads(response.css('script[type="text/javascript"]:contains("analyticsProductData")').re_first(
                r'({.*})').replace('\\', ''))
        except Exception as e:
            data = {}

        product_id = response.css('.product-id::text').get('').split(':')[-1]

        if not product_id:
            return

        price = data.get('price', '')  # Current price
        was_price = response.css('.retailPrice span::text').re_first(r'[0-9.]+')

        item['Product URL'] = response.url
        item['Item ID'] = data.get('id', '')
        item['Product ID'] = product_id
        item['Brand Name'] = response.meta.get('brand_name', '')
        item['Product Name'] = data.get('name', '')
        item['Regular Price'] = was_price if was_price else price
        item['Special Price'] = price if was_price else ''
        item['Short Description'] = '\n\n'.join([''.join(p.css('::text').getall()).strip() for p in response.css('.extended-row p')]) or ''
        item['Long Description'] = self.get_long_description(response)
        item['Product Information'] = ''
        item['Directions'] = '\n'.join(
            response.css('.product-info-section.directions:contains("Directions") div ::text').getall()) or ''
        item['Ingredients'] = '\n'.join(
            response.css('.product-info-section.ingredients:contains("Ingredients") div ::text').getall()) or ''
        item['SKU'] = data.get('id', '')
        item['Image URLs'] = response.css('[u="slides"] .image_enlarger::attr(href)').getall() or response.css('.empty_image::attr(src)').getall()

        yield item

    def get_long_description(self, response):
        general_information = [x.strip() for x in response.css(
            '.product-info-section:contains("General Information") [itemprop="description"] ::text').getall()]
        warnings = response.css('.product-info-section.warnings ::text').getall()
        warnings = warnings if len(warnings) > 4 else []

        return '\n'.join(general_information + warnings).strip()

    def get_json_data(self, response):
        try:
            return response.json() or {}
        except json.JSONDecodeError as e:
            return {}

    def get_attribute(self, attributes, value):
        return '\n'.join([url.get('value', [])[0].get('value') for url in attributes if url.get('name') == value])
