import logging
from collections import OrderedDict
from math import ceil

from scrapy import Request, Spider


class UsedCarsSpider(Spider):
    name = "used_cars"

    csv_headers = ['Title', 'Make', 'Model', 'Year', 'Vin No',
                   'Location', 'Condition', 'Price', 'Average Market Price',
                   'Status', 'Main Image', 'Options', 'Mileage', 'Trim', 'Color',
                   'Body Type', 'Fuel Type', 'Engine', 'Drive Train', 'City Fuel Economy',
                   'Highway Fuel Economy', 'Combined Fuel Economy', 'Dealer Name',
                   'Dealer City', 'Dealer State', 'Dealer Zip', 'Dealer Rating',
                   'Dealer Phone', 'URL']

    custom_settings = {
        # 'CONCURRENT_REQUESTS': 3,
        'FEED_EXPORTERS': {'xlsx': 'scrapy_xlsx.XlsxItemExporter'},
        'FEEDS': {
            f'output/Autotrader Used Cars Details.xlsx': {
                'format': 'xlsx',
                'fields': csv_headers,
            }
        },
    }

    headers_json = {
        'authority': 'www.autotrader.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-PK,en;q=0.9,ur-PK;q=0.8,ur;q=0.7,en-US;q=0.6',
        'cache-control': 'max-age=0',
        'sec-ch-ua': '"Not A(Brand";v="99", "Google Chrome";v="121", "Chromium";v="121"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    }

    def __init__(self, **kwargs):

        super().__init__(**kwargs)
        self.current_scraped_items = []
        self.all_makers = ['AMC', 'ACURA', 'ALFA', 'ASTON', 'AUDI', 'BMW', 'BENTL', 'BUGATTI', 'BUICK', 'CAD', 'CHEV',
                           'CHRY', 'DAEW', 'DATSUN', 'DELOREAN', 'DODGE', 'EAGLE', 'FIAT', 'FER', 'FISK', 'FORD',
                           'FREIGHT', 'GMC', 'GENESIS', 'GEO', 'AMGEN', 'HONDA', 'HYUND', 'INEOS', 'INFIN', 'ISU',
                           'JAG', 'JEEP', 'KARMA', 'KIA', 'LAM', 'ROV', 'LEXUS', 'LINC', 'LOTUS', 'LUCID', 'MAZDA',
                           'MINI', 'MAS', 'MAYBACH', 'MCLAREN', 'MB', 'MERC', 'MIT', 'NISSAN', 'OLDS', 'PLYM',
                           'POLESTAR', 'PONT', 'POR', 'RAM', 'RIVIAN', 'RR', 'SRT', 'SAAB', 'SATURN', 'SCION', 'SUB',
                           'SUZUKI', 'TESLA', 'TOYOTA', 'VINFAST', 'VOLKS', 'VOLVO', 'YUGO', 'SMART']

        self.current_products_scraped = 0

    def start_requests(self):
        vehicle_style = ['CONVERT', 'COUPE', 'HATCH', 'SEDAN', 'SUVCROSS', 'WAGON']
        for v_style in vehicle_style:
            for maker in self.all_makers:
                url = f'https://www.autotrader.com/rest/lsc/listing?allListingType=all-cars&makeCode={maker}&newSearch=false&listingType=USED&channel=ATC&relevanceConfig=relevance-v2&vehicleStyleCode={v_style}'
                yield Request(url=url, callback=self.parse, headers=self.headers_json)

    def parse(self, response, **kwargs):
        try:
            data = response.json()
        except Exception as e:
            return

        total_products = data.get('totalResultCount', 0)
        total_pages = ceil(total_products / 1000)

        if total_products == 0:
            return

        if total_pages <= 2:
            for page_no in range(0, total_pages):
                firstRecord = page_no * 1000
                url = f"{response.url}&firstRecord={firstRecord}&numRecords=1000"
                yield Request(url=url, callback=self.parse_product_detail, headers=self.headers_json, dont_filter=True)
        else:
            if 'fuel_type' not in response.meta:  # Fuel Type Filter
                fuel_types = ['DSL', 'ELE', 'GSL', 'HYB', 'HYD', 'PIH']
                yield from self.yield_requests(response, fuel_types, 'fuel_type', 'fuelTypeGroup')

            if 'sellerType' not in response.meta:  # Seller Type Filter
                seller_types = ['d', 'p']
                yield from self.yield_requests(response, seller_types, 'sellerType', 'sellerType')

            if 'transmission' not in response.meta:  # Transmission Type Filter
                transmission_codes = ['AUT', 'MAN']
                yield from self.yield_requests(response, transmission_codes, 'transmission', 'transmissionCodes')

            if 'mileage' not in response.meta:  # Milage Filter
                mileage_list = ['15000', '30000', '45000', '60000', '75000', '100000', '150000', '200000', '200001']
                yield from self.yield_requests(response, mileage_list, 'mileage', 'mileage')

            if 'door_code' not in response.meta:  # Vehicle Doors Filter
                            doorcode_list = ['2', '3', '4', '5', '6']
                            yield from self.yield_requests(response, doorcode_list, 'door_code', 'doorCode')

            if 'min_year' not in response.meta:  # Year Base Filter
                for min_year, max_year in zip(range(1980, 2023), range(1981, 2024)):
                    url = f'{response.url}&endYear={max_year}&startYear={min_year}'
                    meta = response.meta.copy()
                    meta['min_year'] = min_year
                    meta['max_year'] = max_year
                    yield Request(url=url, callback=self.parse, headers=self.headers_json, dont_filter=True,
                                  meta=meta)

            elif 'min_price' not in response.meta:  # Prie Base Filter
                if total_pages < 10:
                    filters = [(0, 20000), (20000, 30000), (30000, 40000), (40000, 50000), (50000, 60000),
                               (60000, 70000), (70000, 80000), (80000, 90000),
                               (90000, 100000), (100000, 500000), (500000, 100000), (100000, 200000),
                               (200000, 400000), (400000, 700000), (700000, 2000000), (2000000, 5000000),
                               (5000000, 8000000), (8000000, 20000000), (20000000, 30000000)]
                else:
                    filters = [(0, 20000), (20000, 30000), (30000, 40000), (40000, 50000), (60000, 60000),
                               (60000, 80000), (80000, 100000),
                               (100000, 250000), (250000, 500000), (500000, 100000), (100000, 150000), (150000, 200000),
                               (200000, 2500000), (250000, 300000),
                               (300000, 400000), (400000, 500000), (500000, 700000), (700000, 700000),
                               (700000, 1000000), (1000000, 2000000), (2000000, 3000000), (3000000, 4000000),
                               (4000000, 5000000), (5000000, 6000000), (6000000, 7000000), (7000000, 8000000),
                               (8000000, 8900000), (8900000, 9300000), (9300000, 10000000),
                               (10000000, 15000000),
                               (15000000, 20000000), (20000000, 22000000), (22000000, 25000000), (25000000, 27000000),
                               (27000000, 30000000)]

                for min_price, max_price in filters:
                    url = f'{response.url}&minPrice={min_price}&maxPrice={max_price}'
                    meta = response.meta.copy()
                    meta['min_price'] = min_price
                    meta['max_price'] = max_price
                    yield Request(url=url, callback=self.parse, headers=self.headers_json, dont_filter=True,
                                  meta=meta)

    def parse_product_detail(self, response):
        try:
            data = response.json()
        except Exception as e:
            print(f"Error while parsing used cars: {e}")
            return

        products = data.get('listings', [{}])

        if not products:
            return

        for product in products:
            # Extract basic information from the JSON data
            p_id = product.get('id', '')
            if p_id in self.current_scraped_items:
                continue

            make = product.get('make', {}).get('name', '')
            model = product.get('model', {}).get('name', '')
            year = product.get('year', 0)
            condition = product.get('listingTypes', {})[0].get('name', '') or product.get('listingType', '')
            price = product.get('pricingDetail', {}).get('salePrice', 0)
            avg_market_price = product.get('pricingDetail', {}).get('kbbFppAmount', 0.0)

            # Create an ordered dictionary to store item data
            item = OrderedDict()
            item['Title'] = product.get('title', '').replace(str(year), '').replace(condition, '').strip()
            item['Make'] = make
            item['Model'] = model.replace(str(make), '').replace(str(year), '').strip()
            item['Year'] = year if year else ''
            item['Vin No'] = product.get('vin', '')

            # Populate additional fields
            item['Location'] = ''
            item['Condition'] = condition
            item['Price'] = price if price else ''
            item['Average Market Price'] = avg_market_price if avg_market_price else ''
            item['Status'] = product.get('pricingDetail', {}).get('dealIndicator', '')
            item['Main Image'] = ''.join(
                [img.get('src', '') for img in product.get('images', {}).get('sources', [{}])][:1])
            item['Options'] = self.get_options(product)
            milage = product.get('mileage', {}).get('value', '').strip()
            item['Mileage'] = milage if milage else ''
            item['Trim'] = product.get('trim', {}).get('code', '')

            # Extract specific specifications
            body_styles = product.get('bodyStyles', [])
            if body_styles:
                body_type = body_styles[0].get('code', '')
            else:
                body_type = ''

            item['Color'] = product.get('color', {}).get('exteriorColor', '')
            item['Body Type'] = body_type
            item['Drive Train'] = product.get('driveType', {}).get('description', '')

            item['Fuel Type'] = product.get('fuelType', {}).get('name', '')
            item['Engine'] = product.get('engine', {}).get('name', '')

            city_fuel = product.get('mpgCity', 0)
            highway_fuel = product.get('mpgHighway', 0)
            item['City Fuel Economy'] = city_fuel if city_fuel else ''
            item['Highway Fuel Economy'] = highway_fuel if highway_fuel else ''
            item['Combined Fuel Economy'] = ''

            # Extract dealer information
            dealer_address = product.get('owner', {}).get('location', {}).get('address', {})
            dealer_rating = product.get('owner', {}).get('rating', {}).get('value', 0.0)
            item['Dealer Name'] = product.get('owner', {}).get('name', '')
            item['Dealer City'] = dealer_address.get('city', '').strip()
            item['Dealer State'] = dealer_address.get('state', '')
            item['Dealer Zip'] = dealer_address.get('zip', '')
            item['Dealer Rating'] = dealer_rating if dealer_rating else ''
            item['Dealer Phone'] = product.get('owner', {}).get('phone', {}).get('value', '')
            item['URL'] = f'https://www.autotrader.com/cars-for-sale/vehicle/{p_id}'

            self.current_products_scraped += 1
            print('Current Scraped Items Counter :', self.current_products_scraped)
            self.current_scraped_items.append(p_id)
            yield item

    def yield_requests(self, response, values, meta_key, url_key):
        for value in values:
            meta = response.meta.copy()
            meta[meta_key] = value
            url = f"{response.url}&{url_key}={value}"
            yield Request(url=url, callback=self.parse, headers=self.headers_json, dont_filter=True, meta=meta)

    def get_options(self, product):
        specifications = product.get('specifications', {})
        options_string = ""

        for key, value in specifications.items():
            label = value.get('label', '')
            option_value = value.get('value', '')
            option_string = f"{label}: {option_value}"
            options_string += f"{key.title()} = [{option_string}]\n"

        return options_string.strip()
