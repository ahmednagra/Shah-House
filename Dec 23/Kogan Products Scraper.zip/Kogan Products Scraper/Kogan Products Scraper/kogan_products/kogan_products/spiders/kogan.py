import re
import json
from datetime import datetime
from collections import OrderedDict
from typing import Union
from urllib.parse import urljoin, urlencode, unquote
from scrapy import Request, Spider, Selector
from twisted.internet.defer import Deferred


class KoganSpider(Spider):
    name = "kogan"
    base_url = 'https://www.kogan.com/au/'

    custom_settings = {
        'CONCURRENT_REQUESTS': 4,
        'RETRY_TIMES': 5,
        'RETRY_HTTP_CODES': [500, 502, 503, 504, 400, 403, 404, 408, 429],

        'FEEDS': {
            f'output/Kogan Products {datetime.now().strftime("%d%m%Y%H%M%S")}.csv': {
                'format': 'csv',
                'fields': ['Product URL', 'Item ID', 'Product ID', 'Category', 'Brand Name', 'Product Name',
                           'Regular Price', 'Special Price', 'Current Price', 'Short Description',
                           'Long Description', 'Product Information', 'Directions', 'Ingredients',
                           'SKU', 'Image URLs'],
            }
        }
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # Set up proxy key and usage flag
        self.proxy_key = self.get_scrapeops_api_key_from_file()
        self.use_proxy = True if self.proxy_key else False

        # Get search URLs from the input file
        self.categories_search_urls = self.get_category_urls_from_file()

        self.current_scrapped_items = []
        self.items_scrapped = 0

        self.errors_list = []

    def start_requests(self):
        if not self.categories_search_urls:
            yield Request(url=self.get_scrapeops_url(self.base_url), callback=self.parse)
        else:
            for url in self.categories_search_urls:
                yield Request(url=self.get_scrapeops_url(url), callback=self.parse)

    def parse(self, response, **kwargs):
        try:
            star = f"THe spider started at {datetime.now().strftime("%d%m%Y%H%M%S")}"
            self.errors_list.append(star)
            categories_urls = self.get_categories_urls(response)

            if not categories_urls:
                yield from self.parse_category(response)

            for subcategory_url in categories_urls:
                url = urljoin(self.base_url, subcategory_url)
                yield Request(url=self.get_scrapeops_url(url), callback=self.parse_category)

        except Exception as e:
            # self.logger.error(f"Error in parse: {e}")
            self.errors_list.append(f"From Parse Method error: {e}  && url = {unquote(response.url.split('url=')[1])}")

    def parse_category(self, response):
        try:
            # Get category URLs
            categories_urls = self.get_parse_categories_urls(response)

            if not categories_urls:
                try:
                    cat = unquote(response.url.split('url=')[1]).split('category/')[1].rstrip('/')
                except Exception as e:
                    cat = unquote(response.url.split('url=')[1]).split('/')[-2]

                url = f'https://www.kogan.com/au/shop/category/{cat}/?page=10'
                yield Request(url=self.get_scrapeops_url(url), callback=self.parse_category_pagination)

            else:
                for category_url in categories_urls:
                    cat = category_url.replace('/?sps=hidden', '').rstrip('/').split('/')[-1]
                    url = f'https://www.kogan.com/au/shop/category/{cat}/?page=10'
                    yield Request(url=self.get_scrapeops_url(url), callback=self.parse_category_pagination)

        except Exception as e:
            # self.logger.error(f"Error in parse_category: {e}")
            self.errors_list.append(f"From parse_category Method error: {e}  && url = {unquote(response.url.split('url=')[1])}")

    def parse_category_pagination(self, response):
        try:
            products_urls = response.css('.rs-infinite-scroll ._1A_Xq a::attr(href)').getall()
            products_urls = [url.split('?ssid')[0] for url in products_urls]

            for product_url in products_urls:
                p_url = urljoin(self.base_url, product_url)
                if p_url in self.current_scrapped_items:
                    continue

                yield Request(url=self.get_scrapeops_url(p_url), callback=self.parse_product_detail)

            # pagination
            response_url = unquote(response.url.split('url=')[1])
            base_url = response_url.split('?page')[0]

            filters = ['featured', 'rating', 'price', '-price', 'newest', 'title', '-title', '-discount']
            for filter_name in filters:
                if 'order_by' in response_url:
                    return

                nex_page_url = f'{base_url}?order_by={filter_name}&page=10'
                yield Request(url=self.get_scrapeops_url(nex_page_url), callback=self.parse_category_pagination)

        except Exception as e:
            self.errors_list.append(f"From parse_category Method error: {e}  && url = {unquote(response.url.split('url=')[1])}")

    def parse_product_detail(self, response):
        try:
            item = OrderedDict()

            url = response.css('[property="og:url"]::attr(content)').get('').strip()
            sku = response.css('[itemProp="gtin13"]::text').get('').strip()
            current_price = response.css('[itemprop="price"]::attr(content)').get('')
            product_information = self.get_product_information(response)

            item['Product URL'] = url
            item['Item ID'] = ''
            item['Product ID'] = ''.join(response.css('meta[itemProp="sku"]::attr(content)').getall())
            item['Category'] = ', '.join(response.css('[itemprop="itemListElement"] [itemprop="name"] ::text').getall())
            item['Brand Name'] = response.css('[itemprop="brand"] meta::attr(content)').get('').strip()
            item['Product Name'] = response.css('._2cmQO h1 ::text').get('').title()
            item['Short Description'] = ''
            item['Current Price'] = current_price
            item['Long Description'] = self.get_product_long_description(response)
            item['Product Information'] = product_information if product_information else ''
            item['Directions'] = ''
            item['Ingredients'] = self.get_ingredients(response)
            item['SKU'] = sku
            item['Image URLs'] = self.get_images_url(response)
            raw_was_price = response.css('[itemprop="price"] ._2tkSX ::text').getall()
            was_price = ''.join([value.replace('$', '') for value in raw_was_price])
            was_price = was_price or ''.join(response.css('#was-price ._2478v ::text').getall()).replace('$', '')

            if was_price:
                item['Regular Price'] = was_price
                item['Special Price'] = ''
            else:
                item['Regular Price'] = ''
                item['Special Price'] = ''

            self.current_scrapped_items.append(url)
            self.items_scrapped += 1
            print("Items Scrapped :", self.items_scrapped)

            yield item

        except Exception as e:
            self.errors_list.append(
                f"From parse_category Method error: {e}  && url = {unquote(response.url.split('url=')[1])}")

    def get_parse_categories_urls(self, response):
        # Extract and decode JSON string
        script_tag = response.css('script:contains(bootstrapData)::text').re_first(r"('{.+}')")
        script_tag = script_tag.encode().decode('unicode-escape')

        # Search for the required pattern
        script_pattern = re.search(r'"servicesMenu":.+?"experiments":', script_tag)

        # Check if the pattern was found
        if script_pattern:
            string = script_pattern.group(0)
            string = string.replace('"servicesMenu": ', '').replace(', "experiments":', '')
        else:
            self.logger.warning("Pattern not found in JSON string.")
            self.errors_list.append(
                f"From get_parse_categories_urls Method error: && url = {unquote(response.url.split('url=')[1])}")

            return

        try:
            # Extract slug from meta
            slug = response.meta.get('slug', '') or unquote(response.url).split('url=')[1].split('category/')[1].rstrip(
                '/').strip()
        except:
            slug = unquote(response.url).split('/')[-2]

        # Parse JSON to get categories dictionary
        categories_dic = json.loads(string)

        sub_categories_urls = []

        # if full website scrape
        if '/au' in slug:
            all_categories = [category.get('categories', [{}]) for category in categories_dic]
            for category in all_categories:
                items = [sub_cat.get('items') for sub_cat in category]
                for item in items:
                    urls = [row.get('href', '') for row in item if row.get('href')]
                    sub_categories_urls.extend(urls)
        else:
            for category_dic in categories_dic:
                sub_categories = category_dic.get('categories', [{}])
                category_url = category_dic.get('href', '')

                if slug in category_url:
                    items_urls = [[item.get('href') for item in row.get('items', [])] for row in
                                  category_dic.get('categories', [{}])]
                    for item_urls in items_urls:
                        sub_categories_urls.extend(item_urls)
                    break

                else:
                    for sub_sub_cat in sub_categories:
                        sub_cat_url = sub_sub_cat.get('href', '')

                        if not sub_cat_url:
                            continue

                        if slug in sub_cat_url:
                            urls = [row.get('href') for row in sub_sub_cat.get('items', [{}]) if row.get('href')]
                            sub_categories_urls.extend(urls)
                            break

                        else:
                            url = [row.get('href', '') for row in sub_sub_cat.get('items', []) if
                                   row.get('href') and slug in row]
                            if url:
                                sub_categories_urls.append(url)
                            continue

        return sub_categories_urls

    def get_categories_urls(self, response):
        try:
            slug = unquote(response.url.split('url=')[1]).split('category/')[1].rstrip('/')
        except:
            slug = ''

        subcat = response.css(
            '[data-filter-group="category"] ul li._1qy5b:not(:first-child) a::attr(href)').getall() or []
        subcat = subcat or response.css(
            '.department-menu__list.L2ZoZ._1njOC li:not(:first-child) a.department-menu__link ::attr(href)').getall()

        subcat = [url for url in subcat if not slug in url]

        return subcat

    def get_all_product_information(self, response):
        product_information = []

        for row in response:
            heading = row.css('h3 ::text').get().title()
            options = row.css('dl div')

            current_row_info = [f"{heading}:"]

            for option in options:
                name = option.css('dt ::text').get('')
                value = option.css('dd ::text').get('')
                current_row_info.append(f'{name} {value}')

            product_information.append('\n'.join(current_row_info))
        # Join the formatted information for all rows
        output = '\n\n'.join(product_information)

        return output

    def get_images_url(self, response):
        images_urls = response.css('[aria-label="Thumbnail Navigation"] button div img::attr(src)').getall()
        full_images_urls = [img.split('?auto')[0] for img in images_urls]
        full_images_urls = ',\n '.join(full_images_urls)
        full_images_urls = full_images_urls or response.css(
            '.image-gallery-slides .image-gallery-image::attr(src)').get('')

        return full_images_urls if full_images_urls else ''

    def get_product_information(self, response):
        information = self.get_all_product_information(
            response=response.css('#specs-accordion div.text-content-with-links > div'))

        # If specification is not found, try extracting from the description section
        if not information:
            feature_tag = response.css('section[itemprop="description"] p:contains("Key features") + ul li')
            information = []

            for row in feature_tag:
                row_text = ''.join(row.css(' ::text').getall())
                information.append(row_text)

        return information if information else ''

    def get_product_long_description(self, response):
        try:
            script_tag = response.css('script:contains(slug) ::text').re_first(r"JSON.parse[(]'(.*)'[)];").encode(
                'utf-8').decode('unicode-escape')
            product = json.loads(script_tag).get('product', {})
            slug = product.get('allSlugs', [])[0].strip()
            description_dict = product.get('bySlug', {}).get(slug, {}).get('description')
            html_tag = Selector(text=description_dict)

            tags_list = html_tag.xpath('//html/body/div/div[2]/*') or html_tag.xpath('//html/body/*')
            description_text_list = []

            for tag in tags_list:
                tag_classes = tag.css('::attr(class)').extract()
                if 'radioHideLabel' in tag_classes or 'radioHide' in tag_classes:
                    continue
                if tag.css('style'):
                    continue
                text = ''.join(tag.css(' ::text').getall())
                if text:
                    description_text_list.append(text)
                    if 'SPECIFICATION' in text:
                        break
            # # Join the extracted text into a single string
            text_format = '\n'.join(description_text_list)

            return text_format.replace('SPECIFICATION', '').strip()

        except Exception as e:
            return ''

    def get_scrapeops_url(self, url):
        if self.use_proxy:
            if 'https://www.kogan.com/api/v1/products/' in url:
                payload = {'api_key': self.proxy_key, 'render_js': 'True', 'url': url}
                return 'https://proxy.scrapeops.io/v1/?' + urlencode(payload)
            else:
                payload = {'api_key': self.proxy_key, 'url': url}
                return 'https://proxy.scrapeops.io/v1/?' + urlencode(payload)
        else:
            return url

    def get_scrapeops_api_key_from_file(self):
        return self.get_input_from_txt('input/scrapeops_proxy_key.txt')[0]

    def get_category_urls_from_file(self):
        return self.get_input_from_txt('input/category_urls.txt')

    def get_input_from_txt(self, file_path):
        with open(file_path, mode='r', encoding='utf-8') as txt_file:
            return [line.strip() for line in txt_file.readlines() if line.strip()] or ['']

    def get_ingredients(self, response):
        try:
            script_tag = response.css('script:contains(slug) ::text').re_first(r"JSON.parse[(]'(.*)'[)];").encode(
                'utf-8').decode('unicode-escape')
            product = json.loads(script_tag).get('product', {})
            slug = product.get('allSlugs', [])[0].strip()
            description_dict = product.get('bySlug', {}).get(slug, {}).get('description')
            html_tag = Selector(text=description_dict)

            tags_list = html_tag.xpath('//html/body/div/div[2]/*') or html_tag.xpath('//html/body/*')
            ingredients_text = ''

            for tag in tags_list:
                tag_classes = tag.css('::attr(class)').extract()
                if 'radioHideLabel' in tag_classes or 'radioHide' in tag_classes:
                    continue
                if tag.css('style'):
                    continue
                text = ''.join(tag.css(' ::text').getall())
                if 'Ingredients:' in text:
                    ingredients_text = text.split('Ingredients:', 1)[-1].strip()
                    break
            if ingredients_text:
                return '\n'.join(['Ingredients:', ingredients_text])
            else:
                return ''
        except Exception as e:
            print(f'Error is up from Ingredients Method :{e}')
            return ''

    def close(spider: Spider, reason):
        try:
            spider.errors_list.append(str(spider.items_scrapped))
            filename = 'ERRORS.txt'  # Corrected the filename string
            with open(filename, 'w') as f:
                for error in spider.errors_list:
                    f.write(f"{error}\n")
            print(f"Errors written to {filename}")
        except Exception as e:
            print(f"Error writing to file: {e}")
