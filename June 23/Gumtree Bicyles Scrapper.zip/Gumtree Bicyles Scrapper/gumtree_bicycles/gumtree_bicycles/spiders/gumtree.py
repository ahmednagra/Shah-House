import datetime
import os

from scrapy import Spider, Request
from openpyxl import load_workbook

from ..items import GumtreeBicyclesItem


class GumtreeSpider(Spider):
    name = "gumtree"

    start_urls = ['https://www.gumtree.com']

    custom_settings = {
        'CONCURRENT_REQUESTS': 4,

        'FEED_EXPORTERS': {
            'xlsx': 'scrapy_xlsx.XlsxItemExporter',
        },

        'FEED_FORMAT': 'xlsx',
        'FEED_URI': 'output/%(name)s_%(time)s.xlsx',
        'FEED_STORE_EMPTY': True,
        'FEED_EXPORT_FIELDS': ['Name', 'Location', 'Price', 'Date_Posted', 'Image_URL', 'Product_URL'],
    }

    cookies = {
        'gt_bff_ab2': '23',
        'gt_ab': 'ln:NHd6ejc=',
        'gt_p': 'id:NjkzODY2MGItMTk0ZC00NzYzLTkzMDgtYzAwNzAyNDFjYTA4',
        'gt_appBanner': '',
        'gt_adconsent': '',
        'GCLB': 'CIibpf_Qx4brdQ',
        '_ga': 'GA1.2.379149818.1684840461',
        '_gid': 'GA1.2.2071025719.1684840461',
        'rbzid': 'HR5f7yo1HG546eIerdmeXNGAW2E970wgg1cHXJhdgGBkMFhDBH6lEBvPs/0L8p9bMMelLNulAr6O6+LWD47Ew7EasCB+yN4szJISCnU321uxMO03PgIJ5XKsZndnRTrHyOLVDI4nRj/C4vjQnKvY0H7TOV0up0iRsXhkMPM13pA8NZeT8Lp3DrkDjjEf/yoR5Va3KDbm6iTohy0v4TU+L2aQispr07iCmqm7TIDf31I=',
        'rbzsessionid': '6e60e5134171904c8fcd3b36c7b2ef83',
        'OptanonAlertBoxClosed': '2023-05-23T11:14:27.345Z',
        'permutive-id': 'da744c06-11eb-48a2-a486-dc2e2b0e3e73',
        'eupubconsent-v2': 'CPsPkB3PsPkB3AcABBENDECsAP_AAH_AAChQJbtf_X__b2_r-_5_f_t0eY1P9_7__-0zjhfdl-8N3f_X_L8X52M7vF36tq4KuR4ku3LBIUdlHPHcTVmw6okVryPsbk2cr7NKJ7PEmnMbO2dYGH9_n1_z-ZKY7___f__z_v-v________7-3f3__5___-__e_V__9zfn9_____9vP___9v-_9__________3_79_7_H9-f_84JbgEmGrcQBdiWOBNtGEUCIEYVhIVQKACigGFogMIHVwU7K4CfWESAFAKAIwIgQ4AoyYBAAABAEhEAEgR4IBAARAIAAQAKhEIACNgEFABYCAQACgOhYoxQBCBIQZEREQpgQESJBQT2VCCUH-hphCHWWAFBo_4qEBEoAYrAiEhYOQ4IkBLxZIFmKN8gBGAFAKJUK1BJ6aABYyIAAAA.f_gAD_gAAAAA',
        '_cc_id': '40a3f97c480fc73de2f5e7ad3890dd47',
        'panoramaId_expiry': '1685445271175',
        'panoramaId': '70fbb926cf43c5201467a533e6e316d539387d24fefd1e86136f09eeae2e2fc8',
        'panoramaIdType': 'panoIndiv',
        '_pubcid': 'a1d56021-3ebd-4978-b0f5-ff6e290bc3ae',
        '_fbp': 'fb.1.1684840518000.369089864',
        '_tt_enable_cookie': '1',
        '_ttp': 'L3sL3ycodYo9T7lWx0zujvZmtBO',
        '_lr_env_src_ats': 'false',
        'ki_r': '',
        'eCG_eh': 'ec=ResultsBrowse:ea=PaginationPage:el=',
        'gtf1067': 'NONE',
        '_clck': 'ujxyof|2|fbx|0|1238',
        'lux_uid': '168508085062137554',
        '_lr_retry_request': 'true',
        '_tq_id.TV-45818190-1.7ba1': '64c376e98121baf4.1684840732.0.1685081911..',
        'ki_t': '1684840732345%3B1685080862386%3B1685081946513%3B4%3B58',
        '__gads': 'ID=f75e8bc600ca1377:T=1684840470:RT=1685082110:S=ALNI_MZrqt-g8Aiav7ZU3XjZgAkvt6bEpg',
        '__gpi': 'UID=00000c337efd0ca6:T=1684840470:RT=1685082110:S=ALNI_MYt8bxuzDsIq3jEI_hgUBJ7nUPptw',
        'gt_userPref': 'lfsk:Y3JpdGljYWwuY3NzLm1hcCx0YW5kZW0=|isSearchOpen:dHJ1ZQ==|recentAdsOne:Y2Fycy12YW5zLW1vdG9yYmlrZXM=|cookiePolicy:dHJ1ZQ==|recentAdsTwo:Zm9yLXNhbGU=|location:YmVsZmFzdA==',
        'OptanonConsent': 'isIABGlobal=false&datestamp=Fri+May+26+2023+11%3A24%3A44+GMT%2B0500+(Pakistan+Standard+Time)&version=6.10.0&hosts=&landingPath=NotLandingPage&groups=FACEB%3A1%2CLIVER%3A1%2CSTACK42%3A1%2CGOOGL%3A1%2CC0026%3A1%2CC0028%3A1%2CC0029%3A1%2CMICRO%3A1%2CTIKTO%3A1%2CC0023%3A1%2CGATPS%3A1%2CC0002%3A1%2CC0003%3A1%2CC0004%3A1%2CC0001%3A1&geolocation=PK%3BPB&AwaitingReconsent=false',
        '_pbjs_userid_consent_data': '6920248605075303',
        'gt_userIntr': 'cnt:MjU=',
        'gt_s': 'sc:ODY=|ar:aHR0cDovL3d3dy5ndW10cmVlLmNvbS9zZWFyY2g/ZGlzdGFuY2U9MTAmZmVhdHVyZWRfZmlsdGVyPWZhbHNlJnBob3Rvc19maWx0ZXI9ZmFsc2UmcT0mc2VhcmNoX2NhdGVnb3J5PWJpY3ljbGVzJnNlYXJjaF9sb2NhdGlvbj1CZWxmYXN0JnNlYXJjaF9zY29wZT1mYWxzZSZzb3J0PWRhdGUmdXJnZW50X2ZpbHRlcj1mYWxzZQ==|st:MTY4NTA4MjI4NTE5MQ==|clicksource_featured:MTQ1ODU5MzczNSwxNDU4NTAwMzMxLDE0NTg0MzY4MTcsMTQ1ODM3OTI1MiwxNDU0MDA3Mzc5|sk:|bci:MUFDRjdENjRENjNFNjE2QTM1MUY2Rjk1RDdEOTYwRkU=|clicksource_nearby:|id:bm9kZTAxN3dhczc2eXU3eDdmdXltaXpmc2Y2b3p5OTY4NzM=|clicksource_natural:MTQ1ODcyMjUxOSwxNDU4NzIyMTgzLDE0NTg3MjIxMzUsMTQ1ODcyMDc4NywxNDUzNTc2MDY4LDE0NTg3MTkzNzUsMTQ1ODcxODQ5NiwxNDU4NzE4MzQxLDE0NTg3MTc1NzQsMTQ1ODcxNjU5NSwxNDU4NzE2NDg3LDE0NTg3MTYyMzUsMTQ1ODcxNjE1MywxNDI2NTQ1NDM1LDE0NTg3MTU5OTUsMTQ1ODcxNTY4NSwxNDU4NzE1NDUzLDE0Mzk5NDEwODMsMTQ1ODcxNDM4MywxNDU4NzEzOTg0LDE0NTg3MTM4MDgsMTQ1MjM2MzgyNSwxNDU4NzExNjg3LDE0NTg3MDk5MzEsMTQ1ODcwOTQyNA==',
        '_clsk': 'zx31c6|1685082285859|11|0|v.clarity.ms/collect',
        'cto_bundle': 'b5aHxV9DalZzWUhsNnp0aU5sUlNpODM1dFNjQUc4dUk1VCUyQm1aa04lMkI5ejN3YmVEYThzTFpqZlJhT01IOWpTOFZFNkZZcnRxcnJaWDRIUXl1WlJBMlFsRnNzU2NMQ25KcHdTSWVjcDU0JTJCdHdlZzdVbzVjVFNEQ0p4THFwa0lFUkZtSmI5cUhieU5zOHBnRGthWUolMkJiUHE1ZjdxQSUzRCUzRA',
        '_gali': 'srp-results',
    }

    headers = {
        'authority': 'www.gumtree.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-PK,en;q=0.9,ur-PK;q=0.8,ur;q=0.7,en-US;q=0.6',
        'cache-control': 'max-age=0',
        # 'cookie': 'gt_bff_ab2=23; gt_ab=ln:NHd6ejc=; gt_p=id:NjkzODY2MGItMTk0ZC00NzYzLTkzMDgtYzAwNzAyNDFjYTA4; gt_appBanner=; gt_adconsent=; GCLB=CIibpf_Qx4brdQ; _ga=GA1.2.379149818.1684840461; _gid=GA1.2.2071025719.1684840461; rbzid=HR5f7yo1HG546eIerdmeXNGAW2E970wgg1cHXJhdgGBkMFhDBH6lEBvPs/0L8p9bMMelLNulAr6O6+LWD47Ew7EasCB+yN4szJISCnU321uxMO03PgIJ5XKsZndnRTrHyOLVDI4nRj/C4vjQnKvY0H7TOV0up0iRsXhkMPM13pA8NZeT8Lp3DrkDjjEf/yoR5Va3KDbm6iTohy0v4TU+L2aQispr07iCmqm7TIDf31I=; rbzsessionid=6e60e5134171904c8fcd3b36c7b2ef83; OptanonAlertBoxClosed=2023-05-23T11:14:27.345Z; permutive-id=da744c06-11eb-48a2-a486-dc2e2b0e3e73; eupubconsent-v2=CPsPkB3PsPkB3AcABBENDECsAP_AAH_AAChQJbtf_X__b2_r-_5_f_t0eY1P9_7__-0zjhfdl-8N3f_X_L8X52M7vF36tq4KuR4ku3LBIUdlHPHcTVmw6okVryPsbk2cr7NKJ7PEmnMbO2dYGH9_n1_z-ZKY7___f__z_v-v________7-3f3__5___-__e_V__9zfn9_____9vP___9v-_9__________3_79_7_H9-f_84JbgEmGrcQBdiWOBNtGEUCIEYVhIVQKACigGFogMIHVwU7K4CfWESAFAKAIwIgQ4AoyYBAAABAEhEAEgR4IBAARAIAAQAKhEIACNgEFABYCAQACgOhYoxQBCBIQZEREQpgQESJBQT2VCCUH-hphCHWWAFBo_4qEBEoAYrAiEhYOQ4IkBLxZIFmKN8gBGAFAKJUK1BJ6aABYyIAAAA.f_gAD_gAAAAA; _cc_id=40a3f97c480fc73de2f5e7ad3890dd47; panoramaId_expiry=1685445271175; panoramaId=70fbb926cf43c5201467a533e6e316d539387d24fefd1e86136f09eeae2e2fc8; panoramaIdType=panoIndiv; _pubcid=a1d56021-3ebd-4978-b0f5-ff6e290bc3ae; _fbp=fb.1.1684840518000.369089864; _tt_enable_cookie=1; _ttp=L3sL3ycodYo9T7lWx0zujvZmtBO; _lr_env_src_ats=false; ki_r=; eCG_eh=ec=ResultsBrowse:ea=PaginationPage:el=; gtf1067=NONE; _clck=ujxyof|2|fbx|0|1238; lux_uid=168508085062137554; _lr_retry_request=true; _tq_id.TV-45818190-1.7ba1=64c376e98121baf4.1684840732.0.1685081911..; ki_t=1684840732345%3B1685080862386%3B1685081946513%3B4%3B58; __gads=ID=f75e8bc600ca1377:T=1684840470:RT=1685082110:S=ALNI_MZrqt-g8Aiav7ZU3XjZgAkvt6bEpg; __gpi=UID=00000c337efd0ca6:T=1684840470:RT=1685082110:S=ALNI_MYt8bxuzDsIq3jEI_hgUBJ7nUPptw; gt_userPref=lfsk:Y3JpdGljYWwuY3NzLm1hcCx0YW5kZW0=|isSearchOpen:dHJ1ZQ==|recentAdsOne:Y2Fycy12YW5zLW1vdG9yYmlrZXM=|cookiePolicy:dHJ1ZQ==|recentAdsTwo:Zm9yLXNhbGU=|location:YmVsZmFzdA==; OptanonConsent=isIABGlobal=false&datestamp=Fri+May+26+2023+11%3A24%3A44+GMT%2B0500+(Pakistan+Standard+Time)&version=6.10.0&hosts=&landingPath=NotLandingPage&groups=FACEB%3A1%2CLIVER%3A1%2CSTACK42%3A1%2CGOOGL%3A1%2CC0026%3A1%2CC0028%3A1%2CC0029%3A1%2CMICRO%3A1%2CTIKTO%3A1%2CC0023%3A1%2CGATPS%3A1%2CC0002%3A1%2CC0003%3A1%2CC0004%3A1%2CC0001%3A1&geolocation=PK%3BPB&AwaitingReconsent=false; _pbjs_userid_consent_data=6920248605075303; gt_userIntr=cnt:MjU=; gt_s=sc:ODY=|ar:aHR0cDovL3d3dy5ndW10cmVlLmNvbS9zZWFyY2g/ZGlzdGFuY2U9MTAmZmVhdHVyZWRfZmlsdGVyPWZhbHNlJnBob3Rvc19maWx0ZXI9ZmFsc2UmcT0mc2VhcmNoX2NhdGVnb3J5PWJpY3ljbGVzJnNlYXJjaF9sb2NhdGlvbj1CZWxmYXN0JnNlYXJjaF9zY29wZT1mYWxzZSZzb3J0PWRhdGUmdXJnZW50X2ZpbHRlcj1mYWxzZQ==|st:MTY4NTA4MjI4NTE5MQ==|clicksource_featured:MTQ1ODU5MzczNSwxNDU4NTAwMzMxLDE0NTg0MzY4MTcsMTQ1ODM3OTI1MiwxNDU0MDA3Mzc5|sk:|bci:MUFDRjdENjRENjNFNjE2QTM1MUY2Rjk1RDdEOTYwRkU=|clicksource_nearby:|id:bm9kZTAxN3dhczc2eXU3eDdmdXltaXpmc2Y2b3p5OTY4NzM=|clicksource_natural:MTQ1ODcyMjUxOSwxNDU4NzIyMTgzLDE0NTg3MjIxMzUsMTQ1ODcyMDc4NywxNDUzNTc2MDY4LDE0NTg3MTkzNzUsMTQ1ODcxODQ5NiwxNDU4NzE4MzQxLDE0NTg3MTc1NzQsMTQ1ODcxNjU5NSwxNDU4NzE2NDg3LDE0NTg3MTYyMzUsMTQ1ODcxNjE1MywxNDI2NTQ1NDM1LDE0NTg3MTU5OTUsMTQ1ODcxNTY4NSwxNDU4NzE1NDUzLDE0Mzk5NDEwODMsMTQ1ODcxNDM4MywxNDU4NzEzOTg0LDE0NTg3MTM4MDgsMTQ1MjM2MzgyNSwxNDU4NzExNjg3LDE0NTg3MDk5MzEsMTQ1ODcwOTQyNA==; _clsk=zx31c6|1685082285859|11|0|v.clarity.ms/collect; cto_bundle=b5aHxV9DalZzWUhsNnp0aU5sUlNpODM1dFNjQUc4dUk1VCUyQm1aa04lMkI5ejN3YmVEYThzTFpqZlJhT01IOWpTOFZFNkZZcnRxcnJaWDRIUXl1WlJBMlFsRnNzU2NMQ25KcHdTSWVjcDU0JTJCdHdlZzdVbzVjVFNEQ0p4THFwa0lFUkZtSmI5cUhieU5zOHBnRGthWUolMkJiUHE1ZjdxQSUzRCUzRA; _gali=srp-results',
        'if-none-match': 'W/"82e42-JNkQCJ1CQZg0qYVcSgxj/p8IZsw"',
        'referer': 'https://www.gumtree.com/for-sale/sports-leisure-travel/bicycles/uk/belfast',
        'sec-ch-ua': '"Google Chrome";v="113", "Chromium";v="113", "Not-A.Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36',
    }

    def __init__(self):
        self.seen_urls = set()
        self.counter = 0
        self.product_urls = self.all_product_urls()
        print('product urls :', len(self.product_urls))

    def parse(self, response):
        for city_name in response.xpath('//div[@class="tabs-content is-active"]//a/@href').getall():
            url = f'https://www.gumtree.com/for-sale/sports-leisure-travel/bicycles/uk{str(city_name)}'

            self.counter += 1
            yield Request(
                url=url,
                headers=self.headers,
                cookies=self.cookies,
                callback=self.products_page,
            )

    def products_page(self, response):
        for product in response.xpath('//ul[contains(@class, "list-listing-maxi")]/li/article')[:1]:
            product_url = response.url[:23] + product.xpath('.//a/@href').get('')
            item = GumtreeBicyclesItem()

            if product_url in self.product_urls:
                print(f'the product url {product_url} already exists')
                continue

            if product_url in self.seen_urls:
                print(f'Drop-item  {product_url} because it already exists')
                continue

            self.seen_urls.add(product_url)

            item['Name'] = product.xpath('.//h2[contains(@class, "listing-title")]/text()').get('').replace('\n', '')
            item['Location'] = product.xpath('.//div[contains(@class, "listing-location")]/span/text()').get(
                '').replace('\n', '')
            price = product.xpath('.//span[contains(@class, "listing-price")]/strong/text()').get('')
            item['Price'] = price
            item['Image_URL'] = product.xpath('.//div[@class = "listing-thumbnail"]//noscript//img/@src').get('')
            item['Product_URL'] = product_url
            today_date = datetime.datetime.now().date()
            date_posting = ''.join(product.xpath('.//span[@data-q="listing-adAge"]/text()').getall()).strip()

            if any(keyword in date_posting for keyword in ['Just now', 'mins', 'hours', 'hour']):
                item['Date_Posted'] = today_date

            elif any(keyword in date_posting for keyword in ['days', 'day']):
                days = int(date_posting.split()[0])
                item['Date_Posted'] = today_date - datetime.timedelta(days=days)

            else:
                item['Date_Posted'] = None

            yield item

        next_page = response.xpath('//li[@class="pagination-next"]/a/@href').get('')

        if next_page:

            yield Request(
                url=response.url[:23] + next_page,
                callback=self.products_page,
            )

    def all_product_urls(self):
        output_folder = 'output'
        all_products_url = []

        for filename in os.listdir(output_folder):
            file_path = os.path.join(output_folder, filename)

            if os.path.isfile(file_path) and filename.endswith('.xlsx') and os.path.getsize(file_path) > 0:

                try:
                    workbook = load_workbook(file_path)
                    sheet = workbook.active

                    for cell in sheet['F']:  # Product url column

                        if cell.value:
                            all_products_url.append(cell.value)

                except Exception as e:
                    print(f"Error reading file: {file_path} - {e}")

        return all_products_url

    def closed(self, reason):
        print('Total requests made :', self.counter)
